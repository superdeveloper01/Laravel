<?php

return [
	'dashboard' => 'Messages gestion',
	'messages' => 'Messages',
	'name' => 'Name',
	'email' => 'Email',		
	'date' => 'Date',
	'seen' => 'Seen',
	'destroy' => 'Destroy',
	'destroy-warning' => 'Really destroy this message ?',
	'fail' => 'Update fail.'	
];