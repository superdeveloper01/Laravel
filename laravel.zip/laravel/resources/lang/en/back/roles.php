<?php

return [
	'dashboard' => 'Roles gestion',
	'roles' => 'Roles',
	'admin' => 'Title for administrators',
	'redac' => 'Title fro redactors',
	'user' => 'Title for users',
	'ok' => 'Roles updated.'
];