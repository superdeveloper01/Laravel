<?php

return [
	'send' => 'Send'
];