<?php

return [
	'title' => 'Formulaire de contact',
	'text' => 'Si vous désirez nous laisser un message veuillez remplir le formulaire suivant :',
	'name' => 'Votre nom',
	'email' => 'Votre Email',
	'message' => 'Votre message',
	'ok' => 'Votre message a bien été enregistré, nous vous répondrons dès que possible.'
];