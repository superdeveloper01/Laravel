<?php

return [
	'send' => 'Envoyer'
];