<?php

return [
	'dashboard' => 'Gestion des commentaires',
	'comments' => 'Commentaires',
	'author' => 'Auteur',		
	'date' => 'Date',
	'post' => 'Article',
	'valid' => 'valide',
	'seen' => 'Vu',
	'destroy' => 'Supprimer',
	'destroy-warning' => 'Vraiment supprimer ce commentaire ?',
	'fail' => 'Echec de la mise à jour.'	
];