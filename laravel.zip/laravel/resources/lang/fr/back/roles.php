<?php

return [
	'dashboard' => 'Gestion des rôles',
	'roles' => 'Rôles',
	'admin' => 'Titre pour la catégorie des administrateurs',
	'redac' => 'Titre pour la catégorie des rédacteurs',
	'user' => 'Titre pour la catégorie des utilisateurs',
	'ok' => 'Les rôles ont bien été mis à jour.'
];