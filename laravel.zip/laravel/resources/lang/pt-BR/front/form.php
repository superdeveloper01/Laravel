<?php

return [
	'send' => 'Enviar'
];