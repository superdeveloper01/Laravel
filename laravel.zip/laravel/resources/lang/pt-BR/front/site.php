<?php

return [
	'title' => 'Laravel 5',
	'sub-title' => 'Um fantástico framework PHP',
	'home' => 'Home',
	'contact' => 'Contato',
	'blog' => 'Blog',
	'register' => 'Cadastro',
	'forget-password' => 'Esqueci minha senha',
	'connection' => 'Login',
	'administration' => 'Administração',
	'redaction' => 'Redação',
	'logout' => 'Sair'
];
