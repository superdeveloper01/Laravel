<?php

return [
	'dashboard' => 'Gestão de Comentários',
	'comments' => 'Comentários',
	'author' => 'Autor',		
	'date' => 'Data',
	'post' => 'Post',
	'valid' => 'válido',
	'seen' => 'revisado',
	'destroy' => 'Excluir',
	'destroy-warning' => 'Realmente destruir este comentário ?',
	'fail' => 'Falha na atualização.'	
];