@extends('back.blog.template')

@section('form')
	{!! Form::open(['url' => 'blog', 'method' => 'post', 'class' => 'form-horizontal panel']) !!}	
@stop
